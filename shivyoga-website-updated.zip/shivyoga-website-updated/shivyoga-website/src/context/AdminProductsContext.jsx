import { createContext, useCallback, useContext, useEffect, useState } from 'react'

const STORAGE_KEY = 'shivyoga_admin_products'
const AdminProductsContext = createContext(null)

function loadStored() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    return raw ? JSON.parse(raw) : []
  } catch {
    return []
  }
}

function saveStored(list) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(list))
  } catch {
    /* storage full or unavailable — ignore */
  }
}

export function AdminProductsProvider({ children }) {
  const [adminProducts, setAdminProducts] = useState(() => loadStored())

  useEffect(() => {
    saveStored(adminProducts)
  }, [adminProducts])

  const addProduct = useCallback((product) => {
    const newProduct = {
      ...product,
      id: `admin_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
      isAdmin: true,
      createdAt: Date.now(),
    }
    setAdminProducts((list) => [newProduct, ...list])
    return newProduct
  }, [])

  const updateProduct = useCallback((id, updates) => {
    setAdminProducts((list) => list.map((p) => (p.id === id ? { ...p, ...updates } : p)))
  }, [])

  const deleteProduct = useCallback((id) => {
    setAdminProducts((list) => list.filter((p) => p.id !== id))
  }, [])

  return (
    <AdminProductsContext.Provider
      value={{ adminProducts, addProduct, updateProduct, deleteProduct }}
    >
      {children}
    </AdminProductsContext.Provider>
  )
}

export function useAdminProducts() {
  const ctx = useContext(AdminProductsContext)
  if (!ctx) throw new Error('useAdminProducts must be used inside AdminProductsProvider')
  return ctx
}
